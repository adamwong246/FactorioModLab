# Hard Science
## Science is hard.

1) Science packs require previous packs as ingredients. Credts to RecursiveScience

2) A suite of labs+, each with additional requirements.
  - Electric
    - Cheaper to build and very weak.
    - Fast but small. You can only take advantage of that speed of you can feed it ingredients fast enough
    - is minable
    - not polluty
  - Fuel burning
    - convenient, but unlocked late-game and very big.
    - Polluty.
    - is minable
  - heat powered
    - unlocked early-game before you have the tech to use it.
    - does not pollute
    - only 2x prod and fewer module slots
    - very sturdy
    - must be constrctured
    - not minable
  - nuclear powered
    - expensive to build
    - not minable
    - not polluty
    - fragile and explodes with fallout
  - Petro powered
    - cheap to build but very polluty
    - is not minable
    - must be built on a surface
