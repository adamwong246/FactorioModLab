# Foundations
## Higher level machines must be built on a stone or cement floor

2nd tier assemblers, belts, inserters, furnaces must be placed on a stone floor.
3rd tier assemblers, belts, inserters and all higher components must be placed on a cement floor. 

