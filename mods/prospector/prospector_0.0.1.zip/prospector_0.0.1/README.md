# Prospector
## Overhauls ores, radars and mining

1) Ores are invisible. You can't see any of them from the map, and only stone and coal can be seen from the 1st person view. 

2) Earth-ore is everywhere. Every empty tile is covered with an infinitely mine-able ore "Earth"